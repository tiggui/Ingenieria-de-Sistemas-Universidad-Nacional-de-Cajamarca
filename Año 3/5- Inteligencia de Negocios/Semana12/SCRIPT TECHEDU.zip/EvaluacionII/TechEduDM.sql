
-- Crear la Dimensi�n Tiempo
CREATE TABLE DimTiempo (
    TiempoId INT PRIMARY KEY IDENTITY(1,1),  -- Clave primaria autoincremental
    Fecha DATE NOT NULL,                      -- Fecha completa
    Mes INT NOT NULL,                         -- Mes de la fecha
    Trimestre INT NOT NULL,                   -- Trimestre de la fecha
    Anio INT NOT NULL                          -- A�o de la fecha
);

-- Crear la Dimensi�n Estudiante
CREATE TABLE DimEstudiante (
    EstudianteId INT PRIMARY KEY IDENTITY(1,1),  -- Clave primaria autoincremental
    IdAlumno CHAR(5),                            -- Clave natural del estudiante (transaccional)
    NombreCompleto VARCHAR(200) NOT NULL,         -- Nombre completo del estudiante
    Email VARCHAR(100),                           -- Email del estudiante
    Telefono VARCHAR(20)                         -- Tel�fono del estudiante
);

-- Crear la Dimensi�n Curso
CREATE TABLE DimCurso (
    CursoId INT PRIMARY KEY IDENTITY(1,1),    -- Clave primaria autoincremental
    IdCurso CHAR(4),                          -- Clave natural del curso (transaccional)
    NombreCurso VARCHAR(100) NOT NULL,         -- Nombre del curso
    Horas INT NOT NULL,                       -- N�mero de horas del curso
    PrecioVenta MONEY                         -- Precio de venta del curso
);

-- Crear la Tabla de Hechos de Estudiantes
CREATE TABLE FacEstudiantes (
    TiempoId INT,                             -- Clave for�nea a DimTiempo
    EstudianteId INT,                         -- Clave for�nea a DimEstudiante
    CursoId INT,                              -- Clave for�nea a DimCurso
    NotaParcial NUMERIC(4,2),                 -- Nota obtenida en el examen parcial
    NotaFinal NUMERIC(4,2),                   -- Nota obtenida en el examen final
    EstadoMatricula VARCHAR(20),              -- Estado de la matr�cula (si ExaFinal no es nulo entonces estado es activo caso contrario inactivo)
    PRIMARY KEY (TiempoId, EstudianteId, CursoId),  -- Clave primaria compuesta
    FOREIGN KEY (TiempoId) REFERENCES DimTiempo(TiempoId),        -- Clave for�nea a DimTiempo
    FOREIGN KEY (EstudianteId) REFERENCES DimEstudiante(EstudianteId),  -- Clave for�nea a DimEstudiante
    FOREIGN KEY (CursoId) REFERENCES DimCurso(CursoId)            -- Clave for�nea a DimCurso
);

