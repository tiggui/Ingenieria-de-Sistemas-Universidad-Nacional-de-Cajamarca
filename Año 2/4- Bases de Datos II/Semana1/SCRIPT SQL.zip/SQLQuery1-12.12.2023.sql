
-- CREATE DATABASE UNC2023
-- DROP DATABASE UNC2023
-- ALTER DATABASE UNC2023

--USE UNC2023
-- CRUD
-- Crear / Leer-Insertar - Modificar - ELiminar
-- Create / Read-Insert - Update - Delete
-- Drop

CREATE TABLE Alumno (
	idalumno int not null,
	Nombre varchar (100),
	Apellidos Varchar(120),
	Sexo char(1),
	FechaNacimiento date,
	Email varchar(100),
	Zip varchar(6)
)

create table curso (
	idCurso nvarchar(50) not null primary key,
	nombrecurso varchar (50),
	creditos char(1),
	idcarrera int not null
)
-- Agregar la llave primaria
alter table alumno
add constraint key_alumno primary key (idalumno)

-- Modificar columna
alter table curso
alter column idCurso nvarchar(50) not null

-- Agregar la llave primaria
--alter table Curso
--add constraint key_curso primary key (idcurso)

create table Facultad (
	idfacultad int not null primary key,
	nombrefacultad varchar (30)
)
-- modificar columna nombrefacultad a not null
alter table Facultad
alter column nombrefacultad varchar(50) not null

create table carrera (
	idcarrera int not null primary key,
	nombrecarrera varchar(50),
	idfacultad int not null
)

--agregar columna idfacultad tabla carrera
--alter table carrera
--add idfacultad int not null

-- agregar llave foranea tabla carrera
alter table carrera
add constraint FK_carrerafacultad
foreign key (idFacultad) references Facultad(idfacultad)

--agregar columna idcarrera tabla curso
--alter table curso
--add idcarrera int not null

-- corrgiendo el tipo dato columna idcarrera
-alter table curso
-alter column idcarrera int not null

-- agregar llave foranea tabla curso
alter table curso
add constraint FK_cursocarrera
foreign key (idcarrera) references carrera (idcarrera)

-- Unir tabla curso con alumno

Create table Matricula(
	idalumno int not null,
	idcurso nvarchar(50) not null,
	fecha datetime,
	detalle nvarchar(100),
	constraint fk_alumnomatricula
	foreign key (idalumno) references Alumno (idalumno),
	constraint fk_cursomatricula
	foreign key (idcurso) references Curso (idcurso)
)

--DML
Select * from carrera






