CREATE DATABASE BLOGEDUCATIVO

USE BLOGEDUCATIVO

CREATE TABLE CATEGORIA (
nombre VARCHAR(20) NOT NULL PRIMARY KEY,
descipcion VARCHAR(50),
imagen IMAGE,
nombre2 VARCHAR(20) FOREIGN KEY REFERENCES CATEGORIA(nombre),
)



CREATE TABLE PROGRAMA (
nombre VARCHAR(20) NOT NULL PRIMARY KEY,
descripcion VARCHAR (40),
)




CREATE TABLE HORARIO(
id_horario INT NOT NULL PRIMARY KEY,
inicio TIME,
fin TIME,
nombre1 VARCHAR(20) FOREIGN KEY REFERENCES PROGRAMA(nombre),
)

CREATE TABLE CONDUCTOR(
nombre2 VARCHAR(20) FOREIGN KEY REFERENCES PROGRAMA(nombre),
nombre VARCHAR(40))

CREATE TABLE OYENTE(
email VARCHAR(20) NOT NULL PRIMARY KEY,
username VARCHAR(20),
pass VARCHAR(20),
fecha_registro DATE,
avatar IMAGE,
)

CREATE TABLE NOTA(
titulo VARCHAR(20) NOT NULL PRIMARY KEY,
contenido VARCHAR(50),
resumen VARCHAR (50),
imagen IMAGE,
nombre3 VARCHAR(20) FOREIGN KEY REFERENCES CATEGORIA(nombre),
nombre4 VARCHAR(20) FOREIGN KEY REFERENCES PROGRAMA(nombre),
)

CREATE TABLE COMENTARIO(
id INT NOT NULL PRIMARY KEY,
texto VARCHAR(50),
email2 VARCHAR(20) FOREIGN KEY REFERENCES OYENTE(email),
titulo2 VARCHAR(20) FOREIGN KEY REFERENCES NOTA(titulo))




INSERT INTO CATEGORIA VALUES('Lectura', 'Reglas de lectura',NULL,NULL)
INSERT INTO CATEGORIA VALUES('Mate', 'Aprende des cero',NULL,NULL)
INSERT INTO CATEGORIA VALUES('Ptogramaci�n', 'Programaci�n para principiantes',NULL,'Lectura')

INSERT INTO PROGRAMA VALUES('Matutino', 'Programa por la ma�ana')
INSERT INTO PROGRAMA VALUES('Atardecer', 'Programa por la tarde')
INSERT INTO PROGRAMA VALUES('Nocturno', 'Programa por la noche')

INSERT INTO HORARIO VALUES(1, '13:23:44','13:23:44','Atardecer')
INSERT INTO HORARIO VALUES(2, '14:00','16:30','Matutino')
INSERT INTO HORARIO VALUES(3, '20:00','22:30', 'Matutino')

INSERT INTO CONDUCTOR VALUES('Matutino','Elver')
INSERT INTO CONDUCTOR VALUES('Atardecer','John')
INSERT INTO CONDUCTOR VALUES('Atardecer','Erick')

INSERT INTO OYENTE VALUES('fake1@mail.com','fake1', 'pass1',GETDATE(),NULL)
INSERT INTO OYENTE VALUES('fake2@mail.com','fake2', 'pass2',GETDATE(),NULL)
INSERT INTO OYENTE VALUES('fake3@mail.com','fake3', 'pass3',GETDATE(),NULL)

INSERT INTO NOTA VALUES('nota1','Este es un comentario','Este es un resumen',NULL, 'Lectura','Matutino')
INSERT INTO NOTA VALUES('nota2','Este es un comentario 2','Este es un resumen 2',NULL, 'Mate','Atardecer')
INSERT INTO NOTA VALUES('nota3','Este es un comentario 3','Este es un resumen 3',NULL, 'Lectura','Atardecer')

INSERT INTO COMENTARIO VALUES(1, 'Este es un comentario','fake1@mail.com','nota1')
INSERT INTO COMENTARIO VALUES(2, 'Este es un comentario 2','fake2@mail.com','nota2')
INSERT INTO COMENTARIO VALUES(3, 'Este es un comentario 3','fake3@mail.com','nota1')


SELECT * FROM CATEGORIA 

SELECT * FROM PROGRAMA 

SELECT * FROM HORARIO 

SELECT * FROM CONDUCTOR 

SELECT * FROM  OYENTE 

SELECT * FROM  NOTA 

SELECT * FROM COMENTARIO
